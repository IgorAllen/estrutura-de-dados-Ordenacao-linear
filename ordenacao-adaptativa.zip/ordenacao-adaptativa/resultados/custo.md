_Python 3.12.3 · Linux x86_64 · 1 CPU_

### 1. Custo do `escolher` por tamanho (chaves aleatórias em [0, 10^9])

| n | método escolhido | `escolher` sozinho (µs) | método sozinho (ms) | `ordenar` (ms) | custo líquido |
|---:|---:|---:|---:|---:|---:|
| 29 | hibrida | 2.9 | 0.010 | 0.013 | +30.7% |
| 100 | hibrida | 6.3 | 0.046 | 0.053 | +16.6% |
| 300 | base | 16.7 | 0.226 | 0.235 | +4.0% |
| 1.000 | base | 54.1 | 0.425 | 0.484 | +14.0% |
| 20.000 | base | 379.8 | 6.171 | 6.312 | +2.3% |
| 200.000 | base | 3446.4 | 72.099 | 69.651 | -3.4% |

### 2. Custo líquido nos quatro cenários

| cenário | escolhido | `escolher` sozinho (µs) | método sozinho | `ordenar` | custo líquido |
|---:|---:|---:|---:|---:|---:|
| Aleatório, chaves grandes (n=20.000, 0..10^9) | base | 394.8 | 6.155 ms | 6.216 ms | +1.0% |
| Faixa estreita (n=20.000, 0..100) | contagem | 453.0 | 0.922 ms | 0.994 ms | +7.8% |
| Quase ordenado (n=20.000, 1% de trocas locais) | insercao | 41.8 | 1.552 ms | 1.423 ms | -8.3% |
| Lista minúscula (n=10) | insercao | 0.1 | 1.66 µs | 1.68 µs | +1.4% |

### 3. Por que a inspeção é feita em C e por amostragem (n = 20.000, chaves em [0, 10^9])

| inspeção | tempo (µs) | % do tempo da base | % do tempo da híbrida |
|---:|---:|---:|---:|
| `min` + `max` (2 passadas em C) — usado | 348 | 5.7% | 1.7% |
| amostra de ~1000 pares adjacentes (fatias em C) — usado | 48 | 0.8% | 0.2% |
| contar TODAS as descidas em C (`sum(map(gt, v, v[1:]))`) | 372 | 6.1% | 1.9% |
| min/max num laço Python (1 passada) | 341 | 5.5% | 1.7% |
| descidas num laço Python (1 passada) | 530 | 8.6% | 2.6% |
| min/max + descidas, 2 laços Python | 959 | 15.6% | 4.8% |

Referência: base = 6.15 ms, híbrida = 20.12 ms para essa lista.

