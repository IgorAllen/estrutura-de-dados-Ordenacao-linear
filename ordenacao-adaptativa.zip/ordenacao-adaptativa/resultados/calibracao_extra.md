# Calibração complementar

_Python 3.12.3 · Linux x86_64 · 1 CPU_

## E. Base × híbrida em listas médias (chaves de 32 bits)

Tempo (µs) por lista (lotes). A base paga 256 cestos por passada, então precisa de n mínimo.

| n | base | híbrida | inserção | vence |
|---:|---:|---:|---:|---:|
| 24 | 131.2 | 8.9 | 7.9 | inserção |
| 32 | 134.0 | 15.8 | 13.4 | inserção |
| 48 | 142.3 | 23.6 | 27.2 | híbrida |
| 64 | 160.3 | 37.1 | 47.1 | híbrida |
| 96 | 170.9 | 60.5 | 100.0 | híbrida |
| 128 | 189.1 | 84.6 | 181.8 | híbrida |
| 192 | 222.3 | 139.6 | 411.3 | híbrida |
| 256 | 262.6 | 251.5 | 750.8 | híbrida |
| 384 | 307.6 | 313.5 | 1662.1 | base |
| 512 | 370.4 | 449.7 | 3145.1 | base |
| 1024 | 587.4 | 982.1 | 13710.8 | base |

## F. Base × híbrida com chaves muito grandes (n = 20.000)

| bits | passadas | base (ms) | híbrida (ms) | vence |
|---:|---:|---:|---:|---:|
| 64 | 8 | 17.8 | 25.8 | base |
| 96 | 12 | 26.7 | 27.6 | base |
| 128 | 16 | 38.9 | 27.6 | híbrida |
| 192 | 24 | 54.6 | 26.4 | híbrida |
| 256 | 32 | 75.0 | 28.3 | híbrida |

## G. Contagem × base na região de empate (k/n entre 0,5 e 5)

| n | k/n | contagem (ms) | base (ms) | vence |
|---:|---:|---:|---:|---:|
| 2000 | 0.5 | 0.24 | 0.46 | contagem |
| 2000 | 1 | 0.30 | 0.41 | contagem |
| 2000 | 2 | 0.37 | 0.40 | contagem |
| 2000 | 3 | 0.49 | 0.41 | base |
| 2000 | 4 | 0.52 | 0.40 | base |
| 2000 | 5 | 0.57 | 0.39 | base |
| 20000 | 0.5 | 2.38 | 3.58 | contagem |
| 20000 | 1 | 3.04 | 3.23 | contagem |
| 20000 | 2 | 3.54 | 3.18 | base |
| 20000 | 3 | 4.42 | 3.47 | base |
| 20000 | 4 | 5.00 | 4.38 | base |
| 20000 | 5 | 5.44 | 4.59 | base |
| 200000 | 0.5 | 22.34 | 68.38 | contagem |
| 200000 | 1 | 28.60 | 52.02 | contagem |
| 200000 | 2 | 38.86 | 51.19 | contagem |
| 200000 | 3 | 48.96 | 51.58 | contagem |
| 200000 | 4 | 52.80 | 52.69 | base |
| 200000 | 5 | 58.46 | 51.73 | base |

## H. Contagem × base com poucos elementos e faixa pequena

Tempo (µs) por lista (lotes), chaves em [0, k).

| n | k | contagem | base | híbrida | vence |
|---:|---:|---:|---:|---:|---:|
| 32 | 16 | 3.8 | 33.2 | 8.9 | contagem |
| 32 | 64 | 5.5 | 33.3 | 10.0 | contagem |
| 64 | 64 | 8.7 | 44.2 | 35.5 | contagem |
| 64 | 256 | 22.3 | 55.7 | 26.7 | contagem |
| 128 | 128 | 17.6 | 45.3 | 58.4 | contagem |
| 256 | 256 | 34.0 | 58.4 | 136.4 | contagem |
| 256 | 1000 | 66.7 | 116.7 | 154.3 | contagem |

