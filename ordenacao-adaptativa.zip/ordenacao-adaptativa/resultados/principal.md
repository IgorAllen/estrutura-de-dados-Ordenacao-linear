_Python 3.12.3 · Linux x86_64 · 1 CPU_

### Cenários 1–3: tempo mediano (ms)

| Cenário | inserção | intercalação | rápida | híbrida | contagem | base | ordenar | sorted (ref.) | `escolher` pegou |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
| Aleatório, chaves grandes (n=20.000, 0..10^9) | 5841.95 | 29.62 | 30.75 | 22.00 | estoura | **6.70** | 6.49 | 2.96 | base |
| Faixa estreita (n=20.000, 0..100) | 5152.63 | 27.50 | 7.57 | 7.23 | **0.94** | 1.53 | 1.13 | 2.18 | contagem |
| Quase ordenado (n=20.000, 1% de trocas locais) | **1.45** | 21.58 | 26.53 | 16.15 | estoura | 6.66 | 1.49 | 0.20 | insercao |

### Cenário 4: lista minúscula, tempo por lista (µs)

| Cenário | inserção | intercalação | rápida | híbrida | contagem | base | ordenar | sorted (ref.) | `escolher` pegou |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
| Lista minúscula (n=10) | **1.73** | 6.63 | 7.15 | 1.80 | 25.93 | 67.80 | 1.77 | 0.30 | insercao |

_Negrito = melhor dos seis métodos fixos. “estoura” = a contagem recusou a faixa (precisaria de 10^9 contadores). `sorted` (Timsort em C) é só referência, fora da disputa._

### Razão ao melhor método fixo de cada cenário (1,00 = empatou com o melhor)

| Método | Cen. 1 | Cen. 2 | Cen. 3 | Cen. 4 | Pior | Média geométrica |
|---|---:|---:|---:|---:|---:|---:|
| inserção | 872.33× | 5496.22× | 1.00× | 1.00× | 5496.22× | 46.79× |
| intercalação | 4.42× | 29.33× | 14.87× | 3.84× | 29.33× | 9.28× |
| rápida | 4.59× | 8.08× | 18.28× | 4.14× | 18.28× | 7.28× |
| híbrida | 3.29× | 7.72× | 11.13× | 1.04× | 11.13× | 4.14× |
| contagem | falha | 1.00× | falha | 15.02× | falha | — |
| base | 1.00× | 1.64× | 4.59× | 39.27× | 39.27× | 4.14× |
| ordenar | 0.97× | 1.21× | 1.03× | 1.02× | 1.21× | 1.05× |
| sorted (ref.) | 0.44× | 2.32× | 0.14× | 0.17× | 2.32× | 0.39× |
