_Python 3.12.3 · Linux x86_64 · 1 CPU_

Cada candidato: 15 listas de 20.000 inteiros. “Pegou” = método que `escolher` devolveu (contagem de listas). Razão = tempo do escolhido ÷ tempo do melhor método aplicável.

| candidato | pegou | melhor | razão mediana | pior razão |
|---|---|---|---:|---:|
| A. ordenada + 5 elementos jogados longe (0,03%) | inserção 10×, base 5× | inserção 11×, base 4× | 1.00× | 1.63× |
| B. ordenada + 20 elementos jogados longe (0,1%) | base 13×, inserção 2× | base 15× | 1.00× | 2.85× |
| C. ordenada + 40 elementos jogados longe (0,2%) | base 15× | base 15× | 1.00× | 1.00× |
| D. ordenada + 200 elementos jogados longe (1%) | base 15× | base 15× | 1.00× | 1.00× |
| E. ordenada, 10% dos blocos de 30 embaralhados | base 15× | inserção 15× | 3.06× | 5.44× |
| F. faixa estreita (0..100) com 1 outlier de 10^9 | base 15× | base 15× | 1.00× | 1.00× |
