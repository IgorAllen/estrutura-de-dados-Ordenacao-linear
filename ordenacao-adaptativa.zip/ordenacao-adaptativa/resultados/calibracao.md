# Calibração dos limiares

_Python 3.12.3 · Linux x86_64 · 1 CPU_

## A. Lista pequena: até que tamanho a inserção vence?

Tempo (µs) para ordenar uma lista aleatória de n elementos (mediana sobre lotes de 200 listas).

| n | inserção | híbrida | intercalação | rápida | vence |
|---:|---:|---:|---:|---:|---:|
| 2 | 0.2 | 0.3 | 0.6 | 0.8 | inserção |
| 5 | 0.6 | 0.6 | 2.6 | 2.5 | inserção |
| 8 | 1.0 | 1.0 | 4.8 | 5.0 | inserção |
| 12 | 2.2 | 2.3 | 8.0 | 8.3 | inserção |
| 16 | 3.4 | 3.6 | 11.2 | 11.6 | inserção |
| 20 | 5.1 | 5.8 | 14.5 | 14.8 | inserção |
| 24 | 6.4 | 7.0 | 17.9 | 17.7 | inserção |
| 32 | 10.9 | 10.4 | 23.2 | 24.8 | híbrida |
| 48 | 24.2 | 19.0 | 41.4 | 39.0 | híbrida |
| 64 | 43.5 | 42.5 | 50.2 | 52.6 | híbrida |
| 96 | 92.2 | 44.6 | 81.4 | 82.5 | híbrida |
| 128 | 152.6 | 60.1 | 112.5 | 179.7 | híbrida |

## B. Contagem × faixa de valores (k)

Tempo (ms) com n elementos uniformes em [0, k). `k/n` é a razão faixa/dados.

**n = 2.000**

| k | k/n | contagem | base | híbrida | intercalação | vence |
|---:|---:|---:|---:|---:|---:|---:|
| 100 | 0.05 | 0.10 | 0.18 | 0.85 | 2.32 | contagem |
| 1.000 | 0.5 | 0.22 | 0.43 | 1.51 | 2.57 | contagem |
| 10.000 | 5 | 0.56 | 0.37 | 1.56 | 2.46 | base |
| 100.000 | 50 | 3.19 | 0.55 | 1.54 | 2.31 | base |
| 1.000.000 | 500 | 29.44 | 0.56 | 1.43 | 2.41 | base |
| 10.000.000 | 5000 | 334.32 | 0.57 | 1.57 | 2.36 | base |

**n = 20.000**

| k | k/n | contagem | base | híbrida | intercalação | vence |
|---:|---:|---:|---:|---:|---:|---:|
| 100 | 0.005 | 0.90 | 1.48 | 7.26 | 25.85 | contagem |
| 1.000 | 0.05 | 1.41 | 3.65 | 13.36 | 29.44 | contagem |
| 10.000 | 0.5 | 2.09 | 3.25 | 19.26 | 28.99 | contagem |
| 100.000 | 5 | 5.73 | 4.64 | 21.14 | 29.30 | base |
| 1.000.000 | 50 | 32.40 | 4.26 | 20.10 | 26.52 | base |
| 10.000.000 | 500 | 348.19 | 4.64 | 20.13 | 27.84 | base |

**n = 200.000**

| k | k/n | contagem | base | híbrida | intercalação | vence |
|---:|---:|---:|---:|---:|---:|---:|
| 100 | 0.0005 | 11.65 | 15.68 | 72.63 | 318.62 | contagem |
| 1.000 | 0.005 | 13.11 | 39.72 | 135.12 | 359.18 | contagem |
| 10.000 | 0.05 | 12.13 | 35.21 | 188.62 | 396.43 | contagem |
| 100.000 | 0.5 | 22.60 | 53.93 | 244.23 | 367.49 | contagem |
| 1.000.000 | 5 | 65.59 | 58.56 | 276.10 | 354.87 | base |
| 10.000.000 | 50 | 375.88 | 55.15 | 283.23 | 355.64 | base |

## C. Base × métodos por comparação, segundo o tamanho das chaves

Tempo (ms) com n elementos uniformes em [0, 2^bits). Passadas da base = ⌈bits/8⌉.

**n = 2.000**

| bits | passadas | base | híbrida | intercalação | rápida | vence |
|---:|---:|---:|---:|---:|---:|---:|
| 8 | 1 | 0.20 | 1.12 | 2.35 | 1.18 | base |
| 16 | 2 | 0.40 | 1.56 | 2.30 | 2.40 | base |
| 32 | 4 | 0.95 | 2.02 | 2.36 | 2.74 | base |
| 64 | 8 | 1.91 | 1.90 | 2.48 | 2.87 | híbrida |

**n = 20.000**

| bits | passadas | base | híbrida | intercalação | rápida | vence |
|---:|---:|---:|---:|---:|---:|---:|
| 8 | 1 | 1.51 | 9.06 | 27.02 | 8.64 | base |
| 16 | 2 | 3.44 | 21.60 | 29.30 | 27.86 | base |
| 32 | 4 | 8.18 | 30.69 | 32.18 | 43.99 | base |
| 64 | 8 | 16.42 | 26.81 | 29.59 | 36.44 | base |

**n = 200.000**

| bits | passadas | base | híbrida | intercalação | rápida | vence |
|---:|---:|---:|---:|---:|---:|---:|
| 8 | 1 | 14.92 | 92.81 | 299.70 | 84.34 | base |
| 16 | 2 | 36.86 | 223.77 | 356.59 | 275.16 | base |
| 32 | 4 | 90.80 | 305.74 | 374.48 | 409.32 | base |
| 64 | 8 | 188.39 | 348.03 | 375.70 | 466.89 | base |

## D. Quase ordenado: quando a inserção deixa de compensar?

n = 20.000, chaves em [0, 10^9]. Lista ordenada e depois `p·n` trocas entre posições a distância ≤ w. `desc` = fração de pares adjacentes fora de ordem (medida exata).

**distância máxima das trocas w = 10**

| trocas | desc | inserção | base | híbrida | vence |
|---:|---:|---:|---:|---:|---:|
| 0.1% | 0.2% | 2.56 | 6.45 | 15.43 | inserção |
| 0.5% | 1.0% | 1.42 | 6.68 | 15.71 | inserção |
| 1% | 1.8% | 1.40 | 6.82 | 14.68 | inserção |
| 2% | 3.7% | 1.52 | 6.37 | 15.01 | inserção |
| 5% | 8.6% | 1.79 | 6.13 | 14.97 | inserção |
| 25% | 29.6% | 3.25 | 5.88 | 16.50 | inserção |

**distância máxima das trocas w = 1000**

| trocas | desc | inserção | base | híbrida | vence |
|---:|---:|---:|---:|---:|---:|
| 0.1% | 0.2% | 2.40 | 6.09 | 14.46 | inserção |
| 0.5% | 1.0% | 6.48 | 6.23 | 14.73 | base |
| 1% | 1.9% | 11.45 | 5.89 | 14.58 | base |
| 2% | 3.9% | 21.65 | 5.69 | 15.86 | base |
| 5% | 9.0% | 49.35 | 6.39 | 16.06 | base |
| 25% | 31.2% | 168.99 | 5.66 | 17.33 | base |

**distância máxima das trocas w = 20000**

| trocas | desc | inserção | base | híbrida | vence |
|---:|---:|---:|---:|---:|---:|
| 0.1% | 0.2% | 11.28 | 6.44 | 15.31 | base |
| 0.5% | 0.7% | 44.74 | 6.12 | 14.26 | base |
| 1% | 1.5% | 101.90 | 6.21 | 14.94 | base |
| 2% | 2.9% | 182.55 | 6.16 | 15.55 | base |
| 5% | 6.8% | 413.04 | 5.81 | 15.18 | base |
| 25% | 25.9% | 1914.60 | 6.49 | 17.84 | base |

