"""Medição principal: `ordenar` contra os seis métodos fixos nos quatro cenários.

Rodar:  python benchmarks/medir.py
Gera:   resultados/principal.md, resultados/principal.csv, resultados/grafico_cenarios.png
"""
import csv
import math
import os
import random
import statistics

from util import info_maquina, tempo, tempo_lote
from ordenacao import insercao, intercalacao, rapida, hibrida, contagem, base, escolher, ordenar
import cenarios

PASTA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "resultados")
FIXOS = [("inserção", insercao), ("intercalação", intercalacao), ("rápida", rapida),
         ("híbrida", hibrida), ("contagem", contagem), ("base", base)]
TODOS = FIXOS + [("ordenar", ordenar), ("sorted (ref.)", sorted)]
INSTANCIAS = 3
LOTE_MINUSCULA = 200


def medir_grande(gerar):
    rng = random.Random(100)
    dados = [gerar(rng) for _ in range(INSTANCIAS)]
    res, execs = {}, {}
    for nome, f in TODOS:
        ts, ne = [], 0
        try:
            for d in dados:
                t, k, saida = tempo(f, d)
                assert saida == sorted(d), f"{nome} errou a ordenação"
                ts.append(t)
                ne += k
                if t > 2.0:          # método lento: uma instância basta
                    break
            res[nome] = statistics.median(ts)
        except MemoryError:
            res[nome] = None         # recusou: faixa grande demais
        execs[nome] = ne
        print(f"   {nome:<14} {'—' if res[nome] is None else f'{res[nome]*1000:10.2f} ms'}  ({ne} exec.)", flush=True)
    return res, escolher(dados[0]).__name__


def medir_minuscula(gerar):
    rng = random.Random(100)
    lote = [gerar(rng) for _ in range(LOTE_MINUSCULA)]
    res = {}
    for nome, f in TODOS:
        assert all(f(d) == sorted(d) for d in lote)
        res[nome] = tempo_lote(f, lote, reps=21)
        print(f"   {nome:<14} {res[nome]*1e6:10.2f} µs/lista", flush=True)
    return res, escolher(lote[0]).__name__


def fmt(t, micro=False):
    if t is None:
        return "estoura"
    return f"{t*1e6:.2f}" if micro else f"{t*1000:.2f}"


def main():
    print(info_maquina())
    resultados = []
    for i, (titulo, gerar) in enumerate(cenarios.CENARIOS):
        print(f"\n[{i+1}] {titulo}", flush=True)
        if i == 3:
            res, escolhido = medir_minuscula(gerar)
        else:
            res, escolhido = medir_grande(gerar)
        print(f"   escolher -> {escolhido}")
        resultados.append((titulo, res, escolhido, i == 3))

    # ---------- razões ao melhor método fixo
    razoes = {nome: [] for nome, _ in TODOS}
    vencedores = []
    for titulo, res, escolhido, micro in resultados:
        fixos_ok = {n: res[n] for n, _ in FIXOS if res[n] is not None}
        melhor = min(fixos_ok, key=fixos_ok.get)
        vencedores.append(melhor)
        for nome, _ in TODOS:
            razoes[nome].append(None if res[nome] is None else res[nome] / fixos_ok[melhor])

    with open(os.path.join(PASTA, "principal.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["cenario", "unidade", "escolhido"] + [n for n, _ in TODOS])
        for titulo, res, escolhido, micro in resultados:
            w.writerow([titulo, "us/lista" if micro else "ms", escolhido] +
                       [("" if res[n] is None else f"{res[n]*(1e6 if micro else 1e3):.4f}") for n, _ in TODOS])

    L = [f"_{info_maquina()}_\n"]
    L.append("### Cenários 1–3: tempo mediano (ms)\n")
    cab = ["Cenário"] + [n for n, _ in TODOS] + ["`escolher` pegou"]
    L.append("| " + " | ".join(cab) + " |")
    L.append("|" + "|".join(["---"] + ["---:"] * len(TODOS) + ["---"]) + "|")
    for (titulo, res, escolhido, micro), venc in zip(resultados, vencedores):
        if micro:
            continue
        cel = []
        for n, _ in TODOS:
            s = fmt(res[n])
            cel.append(f"**{s}**" if n == venc else s)
        L.append("| " + " | ".join([titulo] + cel + [escolhido]) + " |")
    L.append("\n### Cenário 4: lista minúscula, tempo por lista (µs)\n")
    L.append("| " + " | ".join(cab) + " |")
    L.append("|" + "|".join(["---"] + ["---:"] * len(TODOS) + ["---"]) + "|")
    for (titulo, res, escolhido, micro), venc in zip(resultados, vencedores):
        if not micro:
            continue
        cel = []
        for n, _ in TODOS:
            s = fmt(res[n], micro=True)
            cel.append(f"**{s}**" if n == venc else s)
        L.append("| " + " | ".join([titulo] + cel + [escolhido]) + " |")
    L.append("\n_Negrito = melhor dos seis métodos fixos. “estoura” = a contagem recusou a faixa "
             "(precisaria de 10^9 contadores). `sorted` (Timsort em C) é só referência, fora da disputa._\n")

    L.append("### Razão ao melhor método fixo de cada cenário (1,00 = empatou com o melhor)\n")
    cab2 = ["Método"] + [f"Cen. {i+1}" for i in range(4)] + ["Pior", "Média geométrica"]
    L.append("| " + " | ".join(cab2) + " |")
    L.append("|" + "|".join(["---"] + ["---:"] * 6) + "|")
    for nome, _ in TODOS:
        rs = razoes[nome]
        falha = any(r is None for r in rs)
        ok = [r for r in rs if r is not None]
        pior = "falha" if falha else f"{max(ok):.2f}×"
        gm = "—" if falha else f"{math.exp(sum(math.log(r) for r in ok)/len(ok)):.2f}×"
        L.append("| " + " | ".join([nome] + ["falha" if r is None else f"{r:.2f}×" for r in rs] + [pior, gm]) + " |")
    open(os.path.join(PASTA, "principal.md"), "w", encoding="utf-8").write("\n".join(L) + "\n")
    print("\n" + "\n".join(L))

    # ---------- gráfico
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, eixos = plt.subplots(2, 2, figsize=(12, 7.5))
    nomes = [n for n, _ in TODOS]
    cores = ["#9aa5b1"] * 6 + ["#d1495b", "#6c9a8b"]
    for ax, (titulo, res, escolhido, micro) in zip(eixos.flat, resultados):
        vals = [(res[n] or 0) * (1e6 if micro else 1e3) for n in nomes]
        barras = ax.bar(range(len(nomes)), [v if v > 0 else float("nan") for v in vals], color=cores)
        ax.set_yscale("log")
        ax.set_xticks(range(len(nomes)))
        ax.set_xticklabels(nomes, rotation=40, ha="right", fontsize=8)
        ax.set_ylabel("µs por lista" if micro else "ms")
        ax.set_title(titulo, fontsize=10)
        ax.grid(axis="y", alpha=.3)
        for i, n in enumerate(nomes):
            if res[n] is None:
                ax.text(i, ax.get_ylim()[0] * 1.5, "estoura", rotation=90, ha="center", va="bottom", color="#b00", fontsize=8)
    fig.suptitle("Tempo por cenário (escala log): `ordenar` em vermelho, `sorted` de referência em verde", fontsize=11)
    fig.tight_layout()
    fig.savefig(os.path.join(PASTA, "grafico_cenarios.png"), dpi=150)


if __name__ == "__main__":
    main()
