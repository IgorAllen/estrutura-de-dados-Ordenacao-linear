"""Geradores dos quatro cenários da atividade (e de alguns extras)."""
N = 20_000


def aleatorio_chaves_grandes(rng, n=N):
    """Aleatório, chaves em [0, 10^9]: faixa ~50 mil vezes maior que n."""
    return [rng.randint(0, 10**9) for _ in range(n)]


def faixa_estreita(rng, n=N):
    """Muitos elementos, poucos valores distintos: notas de 0 a 100."""
    return [rng.randint(0, 100) for _ in range(n)]


def quase_ordenado(rng, n=N):
    """Ordenada, depois n/100 trocas entre posições a no máximo 10 de distância."""
    v = sorted(rng.randint(0, 10**9) for _ in range(n))
    for _ in range(n // 100):
        i = rng.randrange(n - 1)
        j = min(n - 1, i + rng.randint(1, 10))
        v[i], v[j] = v[j], v[i]
    return v


def minuscula(rng, n=10):
    """Lista minúscula."""
    return [rng.randint(0, 1000) for _ in range(n)]


CENARIOS = [
    ("Aleatório, chaves grandes (n=20.000, 0..10^9)", aleatorio_chaves_grandes),
    ("Faixa estreita (n=20.000, 0..100)", faixa_estreita),
    ("Quase ordenado (n=20.000, 1% de trocas locais)", quase_ordenado),
    ("Lista minúscula (n=10)", minuscula),
]
