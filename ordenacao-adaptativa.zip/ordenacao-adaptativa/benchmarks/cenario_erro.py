"""Procura cenários em que o `escolher` decide mal.

Rodar:  python benchmarks/cenario_erro.py      (gera resultados/erro.md)
Para cada candidato, 15 listas de 20.000 elementos; compara o método escolhido com o melhor
dos métodos aplicáveis (inserção, base, híbrida, contagem).
"""
import collections
import os
import random
import statistics

from util import info_maquina, tempo
from ordenacao import escolher, insercao, base, hibrida, contagem

SAIDA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "resultados", "erro.md")
N = 20_000
REPS = 15


def ordenada_com_exilados(rng, k):
    """Lista ordenada em que k elementos são jogados para posições aleatórias (longe de casa)."""
    v = sorted(rng.randint(0, 10**9) for _ in range(N))
    for _ in range(k):
        i, j = rng.randrange(N), rng.randrange(N)
        v[i], v[j] = v[j], v[i]
    return v


def ordenada_com_blocos(rng, fracao, tam=30):
    """Ordenada, mas `fracao` dos blocos de `tam` elementos é embaralhada por dentro."""
    v = sorted(rng.randint(0, 10**9) for _ in range(N))
    for ini in range(0, N - tam, tam):
        if rng.random() < fracao:
            bloco = v[ini:ini + tam]
            rng.shuffle(bloco)
            v[ini:ini + tam] = bloco
    return v


def estreita_com_outlier(rng):
    v = [rng.randint(0, 100) for _ in range(N)]
    v[rng.randrange(N)] = 10**9
    return v


CANDIDATOS = [
    ("A. ordenada + 5 elementos jogados longe (0,03%)", lambda r: ordenada_com_exilados(r, 5)),
    ("B. ordenada + 20 elementos jogados longe (0,1%)", lambda r: ordenada_com_exilados(r, 20)),
    ("C. ordenada + 40 elementos jogados longe (0,2%)", lambda r: ordenada_com_exilados(r, 40)),
    ("D. ordenada + 200 elementos jogados longe (1%)", lambda r: ordenada_com_exilados(r, 200)),
    ("E. ordenada, 10% dos blocos de 30 embaralhados", lambda r: ordenada_com_blocos(r, 0.10)),
    ("F. faixa estreita (0..100) com 1 outlier de 10^9", estreita_com_outlier),
]
APLICAVEIS = [("inserção", insercao), ("base", base), ("híbrida", hibrida), ("contagem", contagem)]

L = [f"_{info_maquina()}_\n",
     "Cada candidato: 15 listas de 20.000 inteiros. “Pegou” = método que `escolher` devolveu "
     "(contagem de listas). Razão = tempo do escolhido ÷ tempo do melhor método aplicável.\n",
     "| candidato | pegou | melhor | razão mediana | pior razão |", "|---|---|---|---:|---:|"]
for titulo, gerar in CANDIDATOS:
    rng = random.Random(2026)
    picks, razoes, melhores = collections.Counter(), [], collections.Counter()
    for r in range(REPS):
        v = gerar(rng)
        random.seed(r)
        escolhido = escolher(v)
        nome_esc = next(n for n, f in APLICAVEIS if f is escolhido) if escolhido in [f for _, f in APLICAVEIS] else escolhido.__name__
        t = {}
        for nome, f in APLICAVEIS:
            try:
                t[nome] = tempo(f, v, alvo=0.1, max_reps=5, lento=1.5)[0]
            except MemoryError:
                pass
        melhor = min(t, key=t.get)
        picks[nome_esc] += 1
        melhores[melhor] += 1
        razoes.append(t[nome_esc] / t[melhor])
    L.append(f"| {titulo} | " + ", ".join(f"{k} {c}×" for k, c in picks.most_common()) +
             " | " + ", ".join(f"{k} {c}×" for k, c in melhores.most_common()) +
             f" | {statistics.median(razoes):.2f}× | {max(razoes):.2f}× |")
    print(L[-1], flush=True)
open(SAIDA, "w", encoding="utf-8").write("\n".join(L) + "\n")
