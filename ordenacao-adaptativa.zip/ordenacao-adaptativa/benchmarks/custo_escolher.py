"""Quanto custa rodar o `escolher`? Ele compensa?

Rodar:  python benchmarks/custo_escolher.py      (gera resultados/custo.md)
"""
import os
import random
import statistics
from itertools import islice
from operator import gt

from util import info_maquina, perf, tempo, tempo_lote
from ordenacao import escolher, ordenar
from ordenacao.escolhedor import _quase_ordenada
import cenarios

SAIDA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "resultados", "custo.md")
L = []


def p(t=""):
    print(t, flush=True)
    L.append(t)


def tabela(cab, linhas):
    p("| " + " | ".join(cab) + " |")
    p("|" + "|".join(["---:"] * len(cab)) + "|")
    for l in linhas:
        p("| " + " | ".join(str(x) for x in l) + " |")
    p()


def micro(f, alvo=0.25):
    """Tempo (s) de uma chamada de f(), mediana de 9 lotes."""
    n = 1
    while True:
        t0 = perf()
        for _ in range(n):
            f()
        if perf() - t0 > alvo / 9 or n > 10**6:
            break
        n *= 2
    ts = []
    for _ in range(9):
        t0 = perf()
        for _ in range(n):
            f()
        ts.append((perf() - t0) / n)
    return statistics.median(ts)


def us(t):
    return f"{t*1e6:.1f}"


rng = random.Random(11)
p(f"_{info_maquina()}_\n")

# ------------------------------------------------------------------ 1. por tamanho
# "custo líquido" = ordenar(v) ÷ método escolhido rodando sozinho (descontado o min/max que ele
# já faria sozinho): é o que o escolher realmente acrescenta ao tempo total.
p("### 1. Custo do `escolher` por tamanho (chaves aleatórias em [0, 10^9])\n")
linhas = []
for n in [29, 100, 300, 1000, 20_000, 200_000]:
    v = [rng.randint(0, 10**9) for _ in range(n)]
    random.seed(0)
    te = micro(lambda: escolher(v))
    m = escolher(v)
    tm = tempo(m, v)[0] if n >= 1000 else tempo_lote(m, [v] * 20, reps=15)
    to = tempo(ordenar, v)[0] if n >= 1000 else tempo_lote(ordenar, [v] * 20, reps=15)
    linhas.append([f"{n:,}".replace(",", "."), m.__name__, us(te), f"{tm*1000:.3f}", f"{to*1000:.3f}",
                   f"{(to/tm-1)*100:+.1f}%"])
tabela(["n", "método escolhido", "`escolher` sozinho (µs)", "método sozinho (ms)", "`ordenar` (ms)", "custo líquido"], linhas)

# ------------------------------------------------------------------ 2. nos quatro cenários
p("### 2. Custo líquido nos quatro cenários\n")
linhas = []
for i, (titulo, gerar) in enumerate(cenarios.CENARIOS):
    r = random.Random(100)
    if i == 3:
        lote = [gerar(r) for _ in range(200)]
        te = tempo_lote(escolher, lote, reps=21)
        m = escolher(lote[0])
        tm = tempo_lote(m, lote, reps=21)
        to = tempo_lote(ordenar, lote, reps=21)
        linhas.append([titulo, m.__name__, us(te), f"{tm*1e6:.2f} µs", f"{to*1e6:.2f} µs", f"{(to/tm-1)*100:+.1f}%"])
    else:
        v = gerar(r)
        random.seed(0)
        te = micro(lambda: escolher(v))
        m = escolher(v)
        tm = tempo(m, v)[0]
        to = tempo(ordenar, v)[0]
        linhas.append([titulo, m.__name__, us(te), f"{tm*1000:.3f} ms", f"{to*1000:.3f} ms", f"{(to/tm-1)*100:+.1f}%"])
tabela(["cenário", "escolhido", "`escolher` sozinho (µs)", "método sozinho", "`ordenar`", "custo líquido"], linhas)

# ------------------------------------------------------------------ 3. alternativas de inspeção
p("### 3. Por que a inspeção é feita em C e por amostragem (n = 20.000, chaves em [0, 10^9])\n")
n = 20_000
v = [rng.randint(0, 10**9) for _ in range(n)]
t_base = tempo(__import__("ordenacao").base, v)[0]
t_hib = tempo(__import__("ordenacao").hibrida, v)[0]


def minmax_python():
    lo = hi = v[0]
    for x in v:
        if x < lo:
            lo = x
        elif x > hi:
            hi = x


def descidas_python():
    c = 0
    ant = v[0]
    for x in v:
        if ant > x:
            c += 1
        ant = x


alts = [
    ("`min` + `max` (2 passadas em C) — usado", lambda: (min(v), max(v))),
    ("amostra de ~1000 pares adjacentes (fatias em C) — usado", lambda: _quase_ordenada(v, n)),
    ("contar TODAS as descidas em C (`sum(map(gt, v, v[1:]))`)", lambda: sum(map(gt, v, islice(v, 1, None)))),
    ("min/max num laço Python (1 passada)", minmax_python),
    ("descidas num laço Python (1 passada)", descidas_python),
    ("min/max + descidas, 2 laços Python", lambda: (minmax_python(), descidas_python())),
]
linhas = []
for nome, f in alts:
    t = micro(f)
    linhas.append([nome, f"{t*1e6:.0f}", f"{t/t_base*100:.1f}%", f"{t/t_hib*100:.1f}%"])
tabela(["inspeção", "tempo (µs)", "% do tempo da base", "% do tempo da híbrida"], linhas)
p(f"Referência: base = {t_base*1000:.2f} ms, híbrida = {t_hib*1000:.2f} ms para essa lista.\n")

open(SAIDA, "w", encoding="utf-8").write("\n".join(L) + "\n")
