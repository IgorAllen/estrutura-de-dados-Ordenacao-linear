"""Calibração complementar (limiares finos): rodar depois de calibrar.py.

Rodar:  python benchmarks/calibrar_extra.py      (gera resultados/calibracao_extra.md)
"""
import os
import random

from util import info_maquina, tempo, tempo_lote
from ordenacao.metodos import insercao, intercalacao, hibrida, contagem, base

SAIDA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "resultados", "calibracao_extra.md")
linhas = []


def p(txt=""):
    print(txt, flush=True)
    linhas.append(txt)


def tabela(cab, linhas_):
    p("| " + " | ".join(cab) + " |")
    p("|" + "|".join(["---:"] * len(cab)) + "|")
    for l in linhas_:
        p("| " + " | ".join(str(x) for x in l) + " |")
    p()


rng = random.Random(7)
p(f"# Calibração complementar\n\n_{info_maquina()}_\n")

p("## E. Base × híbrida em listas médias (chaves de 32 bits)\n")
p("Tempo (µs) por lista (lotes). A base paga 256 cestos por passada, então precisa de n mínimo.\n")
linhas_ = []
for n in [24, 32, 48, 64, 96, 128, 192, 256, 384, 512, 1024]:
    lote = [[rng.getrandbits(32) for _ in range(n)] for _ in range(max(20, 20000 // n))]
    t = {"base": tempo_lote(base, lote), "híbrida": tempo_lote(hibrida, lote), "inserção": tempo_lote(insercao, lote)}
    linhas_.append([n] + [f"{t[k]*1e6:.1f}" for k in t] + [min(t, key=t.get)])
tabela(["n", "base", "híbrida", "inserção", "vence"], linhas_)

p("## F. Base × híbrida com chaves muito grandes (n = 20.000)\n")
linhas_ = []
for bits in [64, 96, 128, 192, 256]:
    dados = [rng.getrandbits(bits) for _ in range(20000)]
    tb, th = tempo(base, dados)[0], tempo(hibrida, dados)[0]
    linhas_.append([bits, (bits + 7) // 8, f"{tb*1000:.1f}", f"{th*1000:.1f}", "base" if tb < th else "híbrida"])
tabela(["bits", "passadas", "base (ms)", "híbrida (ms)", "vence"], linhas_)

p("## G. Contagem × base na região de empate (k/n entre 0,5 e 5)\n")
linhas_ = []
for n in [2000, 20000, 200000]:
    for fator in [0.5, 1, 2, 3, 4, 5]:
        k = int(fator * n)
        dados = [rng.randrange(k) for _ in range(n)]
        tc, tb = tempo(contagem, dados)[0], tempo(base, dados)[0]
        linhas_.append([n, fator, f"{tc*1000:.2f}", f"{tb*1000:.2f}", "contagem" if tc < tb else "base"])
tabela(["n", "k/n", "contagem (ms)", "base (ms)", "vence"], linhas_)

p("## H. Contagem × base com poucos elementos e faixa pequena\n")
p("Tempo (µs) por lista (lotes), chaves em [0, k).\n")
linhas_ = []
for n, k in [(32, 16), (32, 64), (64, 64), (64, 256), (128, 128), (256, 256), (256, 1000)]:
    lote = [[rng.randrange(k) for _ in range(n)] for _ in range(100)]
    t = {"contagem": tempo_lote(contagem, lote), "base": tempo_lote(base, lote), "híbrida": tempo_lote(hibrida, lote)}
    linhas_.append([n, k] + [f"{t[x]*1e6:.1f}" for x in t] + [min(t, key=t.get)])
tabela(["n", "k", "contagem", "base", "híbrida", "vence"], linhas_)

with open(SAIDA, "w", encoding="utf-8") as f:
    f.write("\n".join(linhas) + "\n")
print("gravado em", os.path.abspath(SAIDA))
