"""Calibração: de onde vêm os limiares usados pelo `escolher`.

Rodar:  python benchmarks/calibrar.py            (gera resultados/calibracao.md)
"""
import os
import random
import sys

from util import info_maquina, tempo, tempo_lote
from ordenacao.metodos import insercao, intercalacao, rapida, hibrida, contagem, base

SAIDA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "resultados", "calibracao.md")
linhas = []


def p(txt=""):
    print(txt, flush=True)
    linhas.append(txt)


def ms(s):
    return f"{s*1000:.2f}"


def tabela(cab, linhas_):
    p("| " + " | ".join(cab) + " |")
    p("|" + "|".join(["---:"] * len(cab)) + "|")
    for l in linhas_:
        p("| " + " | ".join(str(x) for x in l) + " |")
    p()


rng = random.Random(2026)
p(f"# Calibração dos limiares\n\n_{info_maquina()}_\n")

# ---------------------------------------------------------------- A: listas pequenas
p("## A. Lista pequena: até que tamanho a inserção vence?\n")
p("Tempo (µs) para ordenar uma lista aleatória de n elementos (mediana sobre lotes de 200 listas).\n")
met = {"inserção": insercao, "híbrida": hibrida, "intercalação": intercalacao, "rápida": rapida}
linhas_ = []
for n in [2, 5, 8, 12, 16, 20, 24, 32, 48, 64, 96, 128]:
    lote = [[rng.randint(0, 10**6) for _ in range(n)] for _ in range(200)]
    t = {k: tempo_lote(f, lote) for k, f in met.items()}
    melhor = min(t, key=t.get)
    linhas_.append([n] + [f"{t[k]*1e6:.1f}" for k in met] + [melhor])
tabela(["n"] + list(met) + ["vence"], linhas_)

# ---------------------------------------------------------------- B: contagem x faixa
p("## B. Contagem × faixa de valores (k)\n")
p("Tempo (ms) com n elementos uniformes em [0, k). `k/n` é a razão faixa/dados.\n")
for n in [2000, 20000, 200000]:
    linhas_ = []
    for k in [10**2, 10**3, 10**4, 10**5, 10**6, 10**7]:
        if k > 500 * n and k > 10**5:
            pass
        dados = [rng.randrange(k) for _ in range(n)]
        t = {nome: tempo(f, dados)[0] for nome, f in
             [("contagem", contagem), ("base", base), ("híbrida", hibrida), ("intercalação", intercalacao)]}
        melhor = min(t, key=t.get)
        linhas_.append([f"{k:,}".replace(",", "."), f"{k/n:g}"] + [ms(t[x]) for x in t] + [melhor])
    p(f"**n = {n:,}**".replace(",", "."))
    p()
    tabela(["k", "k/n", "contagem", "base", "híbrida", "intercalação", "vence"], linhas_)

# ---------------------------------------------------------------- C: base x comparação
p("## C. Base × métodos por comparação, segundo o tamanho das chaves\n")
p("Tempo (ms) com n elementos uniformes em [0, 2^bits). Passadas da base = ⌈bits/8⌉.\n")
for n in [2000, 20000, 200000]:
    linhas_ = []
    for bits in [8, 16, 32, 64]:
        dados = [rng.getrandbits(bits) for _ in range(n)]
        t = {nome: tempo(f, dados)[0] for nome, f in
             [("base", base), ("híbrida", hibrida), ("intercalação", intercalacao), ("rápida", rapida)]}
        melhor = min(t, key=t.get)
        linhas_.append([bits, (bits + 7) // 8] + [ms(t[x]) for x in t] + [melhor])
    p(f"**n = {n:,}**".replace(",", "."))
    p()
    tabela(["bits", "passadas", "base", "híbrida", "intercalação", "rápida", "vence"], linhas_)

# ---------------------------------------------------------------- D: quase ordenado
p("## D. Quase ordenado: quando a inserção deixa de compensar?\n")
p("n = 20.000, chaves em [0, 10^9]. Lista ordenada e depois `p·n` trocas entre posições a distância ≤ w. "
  "`desc` = fração de pares adjacentes fora de ordem (medida exata).\n")
n = 20000
for w in [10, 1000, 20000]:
    linhas_ = []
    for frac in [0.001, 0.005, 0.01, 0.02, 0.05, 0.25]:
        v = sorted(rng.randrange(10**9) for _ in range(n))
        for _ in range(int(frac * n)):
            i = rng.randrange(n)
            j = min(n - 1, i + rng.randint(1, w))
            v[i], v[j] = v[j], v[i]
        desc = sum(1 for i in range(n - 1) if v[i] > v[i + 1]) / (n - 1)
        t = {nome: tempo(f, v, lento=1.0)[0] for nome, f in
             [("inserção", insercao), ("base", base), ("híbrida", hibrida)]}
        melhor = min(t, key=t.get)
        linhas_.append([f"{frac*100:g}%", f"{desc*100:.1f}%"] + [ms(t[x]) for x in t] + [melhor])
    p(f"**distância máxima das trocas w = {w}**\n")
    tabela(["trocas", "desc", "inserção", "base", "híbrida", "vence"], linhas_)

with open(SAIDA, "w", encoding="utf-8") as f:
    f.write("\n".join(linhas) + "\n")
print("gravado em", os.path.abspath(SAIDA))
