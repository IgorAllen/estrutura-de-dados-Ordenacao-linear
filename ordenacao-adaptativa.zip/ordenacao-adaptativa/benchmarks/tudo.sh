#!/bin/sh
# Refaz todas as medições (≈ 10–15 min). Rodar da raiz do repositório: sh benchmarks/tudo.sh
cd "$(dirname "$0")" || exit 1
python3 calibrar.py > ../resultados/calibracao.log && \
python3 calibrar_extra.py > ../resultados/calibracao_extra.log && \
python3 medir.py > ../resultados/principal.log && \
python3 custo_escolher.py > ../resultados/custo.log && \
python3 cenario_erro.py > ../resultados/erro.log
