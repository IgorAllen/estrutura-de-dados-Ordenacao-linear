"""Utilitários de cronometragem compartilhados pelos scripts de medição."""
import gc
import os
import platform
import random
import statistics
import sys
import time

# permite rodar os scripts direto de dentro de benchmarks/
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

perf = time.perf_counter


def info_maquina():
    return f"Python {sys.version.split()[0]} · {platform.system()} {platform.machine()} · {os.cpu_count()} CPU"


def tempo(f, dados, alvo=0.4, max_reps=25, lento=2.0, semente=0):
    """Mediana (s) de f(dados). Repete até somar `alvo` s (mín. 3 vezes).
    Se a 1ª execução passar de `lento` s, mede só ela. Devolve (mediana, nº de execuções, última saída)."""
    ts, total = [], 0.0
    gc.collect()
    gc.disable()
    try:
        while True:
            random.seed(semente + len(ts))       # mesma sequência de pivôs em todos os métodos
            t0 = perf()
            saida = f(dados)
            dt = perf() - t0
            ts.append(dt)
            total += dt
            if len(ts) == 1 and dt > lento:
                break
            if len(ts) >= 3 and (total >= alvo or len(ts) >= max_reps):
                break
    finally:
        gc.enable()
    return statistics.median(ts), len(ts), saida


def tempo_lote(f, lista_de_listas, reps=9, semente=0):
    """Mediana (s) para ordenar TODAS as listas do lote, dividida pelo nº de listas.
    Para entradas minúsculas, em que um único cronômetro seria só ruído."""
    ts = []
    gc.collect()
    gc.disable()
    try:
        for r in range(reps):
            random.seed(semente + r)
            t0 = perf()
            for dados in lista_de_listas:
                f(dados)
            ts.append(perf() - t0)
    finally:
        gc.enable()
    return statistics.median(ts) / len(lista_de_listas)
