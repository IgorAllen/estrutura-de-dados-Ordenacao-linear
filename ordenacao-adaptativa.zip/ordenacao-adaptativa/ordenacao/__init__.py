from .metodos import (insercao, intercalacao, rapida, hibrida, contagem, base,
                      METODOS, CORTE_PADRAO, LIMITE_CONTADORES)
from .escolhedor import escolher, ordenar
